import React from "react";

function Home() {
  return (
    <section className="home">
      <h1>Bienvenido a SACMEX</h1>
      <p>
        Plataforma institucional para gestión y visualización de presentaciones
        del Sistema de Agua de la Ciudad de México
      </p>
      <div className="buttons">
        <button>Ver Presentaciones</button>
        <button>Acceso Administrativo</button>
      </div>
    </section>
  );
}

export default Home;
