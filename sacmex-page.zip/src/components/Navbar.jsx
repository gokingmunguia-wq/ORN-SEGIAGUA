import React from "react";

function Navbar() {
  return (
    <nav className="navbar">
      <h2>SACMEX</h2>
      <ul>
        <li><a href="#">Inicio</a></li>
        <li><a href="#">Presentaciones</a></li>
        <li><a href="#">Acceso Administrativo</a></li>
      </ul>
      <button>Iniciar Sesión</button>
    </nav>
  );
}

export default Navbar;
